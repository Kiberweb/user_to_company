<?php

namespace Database\Seeders;

use App\Fakers\Faker;
use App\Models\User;
use App\Models\Company;
use Illuminate\Database\Seeder;

class CompanySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $companys = [
            'Criteo',
            'Digital Element',
            'dotMobi',
            'eBuddy',
            'eDirectory',
            'Enplug',
            'Facebook',
            'Fiksu',
            'Fluent Inc.',
            'Google Inc.',
            'InMobi',
            'Integral Ad Science',
            'Marin Software',
            'Matomy Media',
            'mBlox',
            'Media.net',
            'Neustar',
            'Newsmax Media',
            'OpenMarket',
            'OpenX',
        ];

        $users = User::all();

        if (!is_null($users)) {
            foreach ($users as $user) {
                $phone = array_rand([
                    '067',
                    '050',
                    '063',
                    '099',
                    '044',
                    '068'
                ]);

                $phone .= Faker::randomNumber(7);

                Company::create([
                    'user_id' => $user->id,
                    'title' => array_rand($companys),
                    'phone' => $phone,
                    'description' => 'The advantage of Latin origin and nonsense content Lorem ipsum prevents the reader from being distracted by the content of the text and thus can focus its attention on graphic design.',
                ]);
            }
        }
    }
}
