<?php

namespace App\Http\Controllers;

use App\Models\Company;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CompanyController extends Controller
{
    /**
     * Get a JWT via given credentials.
     *
     * @param  int $id
     * @return \Illuminate\Http\JsonResponse
     */
    public function index(int $id = null): JsonResponse
    {

        if ($id) {
            return response()->json(Company::findOrFail($id));
        }

        $companies = Company::where('user_id', (Auth::user())->id)->orderBy('created_at', 'DESC')->get();

        if (!is_null($companies)) {
            return response()->json([
                'data' => $companies,
            ]);
        }

        return response()->json([
            'data' => 'Not found companies',
        ]);
    }

    /**
     * Get a JWT via given credentials.
     *
     * @param  Request $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function create(Request $request): JsonResponse
    {
        $this->validate($request, [
            'title' => 'required|min:3|max:255',
            'phone' => 'required|min:10|max:15',
            'description' => 'required|min:3|max:255',
        ]);

        try {
            $company = new Company();
            $company->title = $request->get('title');
            $company->phone = $request->get('phone');
            $company->description = $request->get('description');
            $company->user_id = (Auth::user())->id;

            $company->save();

            return response()->json([
                'user' => $company,
                'message' => 'CREATED'
            ], 201);

        } catch (\Throwable $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 500);
        }
    }
}
