<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Fakers\Faker;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    /**
     * Create a new AuthController instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth:api', [
            'except' => [
                'register',
                'signIn',
                'recoverPassword',
            ]
        ]);
    }

    /**
     * Get a JWT via given credentials.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function register(Request $request): JsonResponse
    {
        $this->validate($request, [
            'first_name' => 'required|min:3|max:20',
            'last_name' => 'required|min:3|max:20',
            'email' => 'required|email|max:47',
            'password' => 'required|min:6|max:20',
            'phone' => 'required|min:10|max:15',
        ]);

        try {
            $user = new User();
            $user->first_name = $request->get('last_name');
            $user->last_name = $request->get('last_name');
            $user->email = $request->get('email');
            $user->password = app('hash')->make($request->get('password'));
            $user->phone = $request->get('phone');

            $user->save();

            return response()->json([
                'user' => $user,
                'message' => 'CREATED'
            ], 201);
        } catch (\Exception $e) {
            return response()->json([
                'message' => $e->getMessage(),
            ], 500);
        }
    }

    /**
     * Get a JWT via given credentials.
     *
     * @param  Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function signIn(Request $request): JsonResponse
    {
        $this->validate($request, [
            'email' => 'required|email|max:47',
            'password' => 'required|min:6|max:20',
        ]);

        $credentials = $request->only([
            'email',
            'password',
        ]);

        try {
            if (! $token = auth()->attempt($credentials)) {
                return response()->json(['error' => 'Unauthorized'], 401);
            }
        } catch (\Throwable $e) {
            return response()->json([
                'error' => $e->getMessage(),
            ], 500);
        }

        return $this->respondWithToken($token);
    }

    /**
     *
     * @param  Request  $request
     * @return \Illuminate\Http\JsonResponse
     */
    public function recoverPassword(Request $request): JsonResponse
    {
        $this->validate($request, [
            'email' => 'required|email|max:47',
        ]);

        $user = User::where('email', '=', $request->get('email'))->first();

        $recoverPassword = Faker::randomString(7);

        $user->password = Hash::make($recoverPassword);
        $user->save();

        return response()->json([
            'message' => $recoverPassword,
        ]);
    }

    /**
     * Get the authenticated User.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function currentUser(): JsonResponse
    {
        return response()->json(auth()->user());
    }

    /**
     * Log the user out (Invalidate the token).
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function logout(): JsonResponse
    {
        auth()->logout();
        return response()->json([
            'message' => 'Successfully logged out',
        ]);
    }

    /**
     * Refresh a token.
     *
     * @return \Illuminate\Http\JsonResponse
     */
    public function refresh()
    {
        return $this->respondWithToken(auth()->refresh());
    }
}
