<?php

namespace App\Fakers;

final class Faker
{
    /*
     * Return random string with $length
     *
     * @param int $length
     * @return string
     */
    public static function randomNumber(int $digits): int
    {
        return random_int(
            pow(10, $digits - 1),
            pow(10, $digits) - 1,
        );
    }

    /*
     * Return random string with $length
     *
     * @param int $length
     * @return string
     */
    public static function randomString(int $length = 0): string
    {
        if ($length === 0) {
            $length = mt_rand(10, 100);
        }

        $characters = $characters = ' 0123456789 abcdefghijklmnopqrstuvwxyz ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $charactersLength = strlen($characters);
        $randomString = '';

        for ($index = 0; $index < $length; $index++) {
            $randomString .= $characters[rand(0, $charactersLength - 1)];
        }

        return $randomString;
    }

    /**
     * @return \DateTime
     */
    public static function randomDateTime(): \DateTime
    {
        $dateTime = new \DateTime();
        $randomHours = mt_rand(0, 1000);
        $dateTime->modify(sprintf('-%s hours', $randomHours));

        return $dateTime;
    }

    /**
     * @param array $array
     * @return mixed
     */
    public static function randomInArray(array $array): string
    {
        return $array[array_rand($array)];
    }

    /**
     * @return bool
     */
    public static function randomBoolean(): bool
    {
        return (bool) mt_rand(0, 1);
    }
}
